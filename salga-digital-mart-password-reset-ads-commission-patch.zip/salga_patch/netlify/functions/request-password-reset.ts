import type { Context, Config } from '@netlify/functions';
import { bad, ok, randomCode, sendEmail, sha256, supabase } from './_shared';

export default async (req: Request, _context: Context) => {
  if (req.method !== 'POST') return bad('Method not allowed', 405);
  const { email } = await req.json().catch(() => ({}));
  if (!email || typeof email !== 'string') return bad('Email is required.');

  const normalized = email.trim().toLowerCase();
  const userRes = await supabase(`users?select=id,email&email=eq.${encodeURIComponent(normalized)}&limit=1`);
  if (!userRes.ok) return bad('Unable to process reset request.', 500);
  const users = await userRes.json();

  // Do not reveal whether an account exists.
  if (!Array.isArray(users) || users.length === 0) return ok({ message: 'If that email is registered, a reset code has been sent.' });

  const code = randomCode();
  const codeHash = await sha256(code);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const userId = users[0].id;

  const save = await supabase('password_resets', {
    method: 'POST',
    body: JSON.stringify({ user_id: userId, email: normalized, code_hash: codeHash, expires_at: expiresAt, used: false })
  });
  if (!save.ok) return bad('Unable to create reset request.', 500);

  await sendEmail(normalized, 'Your Salga Digital Mart password reset code', `Your password reset code is ${code}. It expires in 10 minutes. If you did not request this, you can ignore this email.`);
  return ok({ message: 'If that email is registered, a reset code has been sent.' });
};

export const config: Config = { path: '/api/auth/request-password-reset' };
