export type Role='buyer'|'seller'|'admin';
export type Profile={id:string;full_name:string|null;phone:string|null;role:Role;avatar_url:string|null};
export type Business={id:string;owner_id:string;business_name:string;description:string|null;category:string|null;phone:string|null;whatsapp:string|null;address:string|null;logo_url:string|null;cover_url?:string|null;opening_hours?:string|null;status:string;verified?:boolean;created_at:string};
export type Product={id:string;business_id:string;name:string;description:string|null;price:number;image_url:string|null;category:string|null;stock:number;status:string;created_at:string;business?:Business};
export type CartItem=Product & {quantity:number};
