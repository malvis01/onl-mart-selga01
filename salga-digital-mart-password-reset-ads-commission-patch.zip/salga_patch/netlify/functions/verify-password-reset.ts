import type { Context, Config } from '@netlify/functions';
import { bad, ok, sha256, supabase } from './_shared';

export default async (req: Request, _context: Context) => {
  if (req.method !== 'POST') return bad('Method not allowed', 405);
  const { email, code, newPassword } = await req.json().catch(() => ({}));
  if (!email || !code || !newPassword) return bad('Email, code and new password are required.');
  if (typeof newPassword !== 'string' || newPassword.length < 8) return bad('Password must be at least 8 characters.');

  const normalized = String(email).trim().toLowerCase();
  const codeHash = await sha256(String(code).trim());
  const q = `password_resets?select=id,user_id&email=eq.${encodeURIComponent(normalized)}&code_hash=eq.${encodeURIComponent(codeHash)}&used=eq.false&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&order=created_at.desc&limit=1`;
  const resetRes = await supabase(q);
  if (!resetRes.ok) return bad('Unable to verify reset code.', 500);
  const rows = await resetRes.json();
  if (!Array.isArray(rows) || rows.length === 0) return bad('Invalid or expired reset code.', 400);

  // This patch stores a SHA-256 password value for compatibility. For a production auth migration,
  // replace this with the hashing scheme already used by the existing authentication system.
  const passwordHash = await sha256(newPassword);
  const userId = rows[0].user_id;
  const update = await supabase(`users?id=eq.${encodeURIComponent(userId)}`, {
    method: 'PATCH',
    body: JSON.stringify({ password_hash: passwordHash })
  });
  if (!update.ok) return bad('Unable to update password.', 500);

  await supabase(`password_resets?id=eq.${encodeURIComponent(rows[0].id)}`, {
    method: 'PATCH',
    body: JSON.stringify({ used: true })
  });
  return ok({ message: 'Password reset successfully.' });
};

export const config: Config = { path: '/api/auth/verify-password-reset' };
