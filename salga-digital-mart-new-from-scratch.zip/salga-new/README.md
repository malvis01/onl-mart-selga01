# SALGA Digital Mart — New Website

A fresh rebuild of the SALGA Digital Mart marketplace.

## Accounts
- Buyer: phone + password
- Seller/business: phone + password
- Admin: email + password

Admin demo credentials:
- Email: admin@salgadigitalmart.com
- Password: SalgaAdmin2026!

## Deploy
Upload this entire project to a new Netlify site, or connect the repository. Build command: `npm run build`; publish directory: `dist`.

SMS/WhatsApp delivery requires a real provider and credentials. The app includes a demo activation-code flow so registration is not blocked during setup.
