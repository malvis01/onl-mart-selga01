-- Sagbama Digital Marketplace production schema additions.
create table if not exists public.community_posts (
 id uuid primary key default gen_random_uuid(),
 author_id uuid not null references public.profiles(id) on delete cascade,
 content text not null check (length(trim(content)) > 0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.community_comments (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.community_posts(id) on delete cascade,
 author_id uuid not null references public.profiles(id) on delete cascade,
 content text not null check (length(trim(content)) > 0),
 created_at timestamptz not null default now()
);
alter table public.community_posts enable row level security;
alter table public.community_comments enable row level security;
drop policy if exists community_posts_read on public.community_posts;
drop policy if exists community_posts_seller_write on public.community_posts;
drop policy if exists community_comments_read on public.community_comments;
drop policy if exists community_comments_write on public.community_comments;
create policy community_posts_read on public.community_posts for select using (true);
create policy community_posts_seller_write on public.community_posts for insert to authenticated with check ((select role from public.profiles where id=auth.uid()) in ('seller','admin') and author_id=auth.uid());
create policy community_posts_owner_update on public.community_posts for update to authenticated using (author_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin') with check (author_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin');
create policy community_posts_owner_delete on public.community_posts for delete to authenticated using (author_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin');
create policy community_comments_read on public.community_comments for select using (true);
create policy community_comments_write on public.community_comments for insert to authenticated with check (author_id=auth.uid());

-- Public discovery.
drop policy if exists businesses_public_read on public.businesses;
create policy businesses_public_read on public.businesses for select using (status='active');
create policy businesses_owner_read on public.businesses for select to authenticated using (owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin');
drop policy if exists products_public_read on public.products;
create policy products_public_read on public.products for select using (status='active' and approved=true);
create policy products_owner_read on public.products for select to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and (b.owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin')));

-- Profiles: users can read public profile information and edit their own profile.
drop policy if exists profiles_public_read on public.profiles;
create policy profiles_public_read on public.profiles for select using (true);
drop policy if exists profiles_self_insert on public.profiles;
create policy profiles_self_insert on public.profiles for insert to authenticated with check (id=auth.uid() and role in ('buyer','seller'));
create policy profiles_admin_update on public.profiles for update to authenticated using ((select role from public.profiles where id=auth.uid())='admin') with check (true);
drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

-- Seller business ownership.
drop policy if exists businesses_owner_insert on public.businesses;
create policy businesses_owner_insert on public.businesses for insert to authenticated with check (owner_id=auth.uid() and (select role from public.profiles where id=auth.uid()) in ('seller','admin'));
drop policy if exists businesses_owner_update on public.businesses;
create policy businesses_owner_update on public.businesses for update to authenticated using (owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin') with check (owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin');

-- Seller products.
drop policy if exists products_owner_insert on public.products;
create policy products_owner_insert on public.products for insert to authenticated with check (exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid()));
drop policy if exists products_owner_update on public.products;
create policy products_owner_update on public.products for update to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and (b.owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin'))) with check (exists(select 1 from public.businesses b where b.id=business_id and (b.owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin')));
drop policy if exists products_owner_delete on public.products;
create policy products_owner_delete on public.products for delete to authenticated using (exists(select 1 from public.businesses b where b.id=business_id and (b.owner_id=auth.uid() or (select role from public.profiles where id=auth.uid())='admin')));

-- Customer orders and items.
drop policy if exists orders_buyer_insert on public.orders;
create policy orders_buyer_insert on public.orders for insert to authenticated with check (buyer_id=auth.uid());
drop policy if exists orders_buyer_read on public.orders;
create policy orders_buyer_read on public.orders for select to authenticated using (buyer_id=auth.uid() or exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid()) or (select role from public.profiles where id=auth.uid())='admin');
drop policy if exists order_items_buyer_write on public.order_items;
create policy order_items_buyer_write on public.order_items for insert to authenticated with check (exists(select 1 from public.orders o where o.id=order_id and o.buyer_id=auth.uid()));
drop policy if exists order_items_read on public.order_items;
create policy order_items_read on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id=order_id and (o.buyer_id=auth.uid() or exists(select 1 from public.businesses b where b.id=o.business_id and b.owner_id=auth.uid()) or (select role from public.profiles where id=auth.uid())='admin')));

-- Storage bucket for marketplace media.
insert into storage.buckets(id,name,public) values('marketplace','marketplace',true) on conflict (id) do nothing;
drop policy if exists marketplace_public_read on storage.objects;
create policy marketplace_public_read on storage.objects for select using (bucket_id='marketplace');
drop policy if exists marketplace_auth_upload on storage.objects;
create policy marketplace_auth_upload on storage.objects for insert to authenticated with check (bucket_id='marketplace');
drop policy if exists marketplace_owner_update on storage.objects;
create policy marketplace_owner_update on storage.objects for update to authenticated using (bucket_id='marketplace' and owner_id=auth.uid()) with check (bucket_id='marketplace' and owner_id=auth.uid());
drop policy if exists marketplace_owner_delete on storage.objects;
create policy marketplace_owner_delete on storage.objects for delete to authenticated using (bucket_id='marketplace' and owner_id=auth.uid());
