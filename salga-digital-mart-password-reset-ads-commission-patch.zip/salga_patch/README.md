# Salga Digital Mart — password reset + advertising commission patch

This is a deploy-ready Netlify Functions patch for the requested features:

- Password reset by email with a 6-digit code that expires after 10 minutes.
- Advertising campaign creation with a server-side 3% platform commission and 97% business amount.
- SQL schema for the reset and advertising records.

## Important

This patch is **not claimed to be merged into the existing deployed site's frontend**, because the current Netlify connection exposes the project/deployment but not the application's source repository/files. The existing site's authentication and data model must be mapped to these endpoints before deploying this patch to production.

## Environment variables

Set these in Netlify (Functions/runtime scope):

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `RESEND_API_KEY`
- `RESET_FROM_EMAIL`

Never put the Supabase service-role key in browser code.

## Database

Run `sql/schema.sql` in the project's database, adapting `users.id` and `users.password_hash` to the existing user table if needed.

## Frontend

Import the functions in `public/feature-patch-example.js` and connect them to the existing Forgot Password, reset-code, new-password, and business advertising forms.

## Commission

The advertising endpoint calculates:

- Platform commission = `amount * 0.03`
- Business amount = `amount - commission`

The values are calculated server-side and stored with the campaign so the browser cannot simply change the commission to 0%.
