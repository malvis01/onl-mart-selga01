-- Adapt these columns to the existing Salga Digital Mart users table if it already exists.
-- Do NOT expose SUPABASE_SERVICE_ROLE_KEY to browser code.

create table if not exists password_resets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  email text not null,
  code_hash text not null,
  expires_at timestamptz not null,
  used boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists password_resets_lookup_idx
  on password_resets(email, code_hash, used, expires_at);

create table if not exists ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null,
  title text not null,
  amount numeric(14,2) not null check (amount > 0),
  commission_rate numeric(6,5) not null default 0.03,
  commission_amount numeric(14,2) not null,
  business_amount numeric(14,2) not null,
  status text not null default 'pending',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);
