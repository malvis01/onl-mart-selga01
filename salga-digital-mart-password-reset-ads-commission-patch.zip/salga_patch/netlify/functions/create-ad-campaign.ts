import type { Context, Config } from '@netlify/functions';
import { bad, ok, supabase } from './_shared';

export default async (req: Request, _context: Context) => {
  if (req.method !== 'POST') return bad('Method not allowed', 405);
  const body = await req.json().catch(() => ({}));
  const { businessId, amount, title, startsAt, endsAt } = body;
  const naira = Number(amount);
  if (!businessId || !title || !Number.isFinite(naira) || naira <= 0) return bad('businessId, title and a positive amount are required.');

  const commission = Math.round(naira * 0.03 * 100) / 100;
  const businessAmount = Math.round((naira - commission) * 100) / 100;
  const res = await supabase('ad_campaigns', {
    method: 'POST',
    body: JSON.stringify({
      business_id: businessId,
      title,
      amount: naira,
      commission_rate: 0.03,
      commission_amount: commission,
      business_amount: businessAmount,
      starts_at: startsAt || null,
      ends_at: endsAt || null,
      status: 'pending'
    })
  });
  if (!res.ok) return bad('Unable to create advertising campaign.', 500);
  const rows = await res.json();
  return ok({ campaign: Array.isArray(rows) ? rows[0] : rows, commissionRate: 0.03, commissionAmount: commission, businessAmount });
};

export const config: Config = { path: '/api/ads/create-campaign' };
