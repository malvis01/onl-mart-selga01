import {read,write,json,body,hash,now} from "./_shared/store.mjs";

const ADMIN_EMAIL=()=>Netlify.env.get("ADMIN_EMAIL")||"admin@salgadigitalmart.com";
async function currentPassword(){
  const saved=await read("adminSettings",{});
  return saved.password || Netlify.env.get("ADMIN_PASSWORD") || "CHANGE_THIS_ADMIN_PASSWORD";
}
function token(email,password){return "admin_"+hash(String(email)+String(password))}
function code(){return String(Math.floor(100000+Math.random()*900000))}
async function sendResetCode(resetCode){
  const key=Netlify.env.get("RESEND_API_KEY");
  if(!key) return false;
  const from=Netlify.env.get("ADMIN_RESET_FROM")||"SALGA Digital Mart <onboarding@resend.dev>";
  const r=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({from,to:[ADMIN_EMAIL()],subject:"SALGA Digital Mart admin password reset",text:`Your SALGA admin password reset code is ${resetCode}. It expires in 10 minutes. If you did not request this, ignore this email.`})});
  return r.ok;
}
export default async req=>{
  if(req.method==="POST"){
    const b=await body(req);
    if(b.action==="login"){const pass=await currentPassword();if(b.email!==ADMIN_EMAIL()||b.password!==pass)return json({error:"Invalid admin credentials"},401);return json({token:token(ADMIN_EMAIL(),pass)})}
    if(b.action==="request-reset"){
      if(b.email!==ADMIN_EMAIL()) return json({message:"If that email is the administrator email, a reset code has been sent."});
      const c=code(); await write("adminReset",{codeHash:hash(c),expiresAt:Date.now()+10*60*1000,createdAt:now()});
      const sent=await sendResetCode(c);
      if(!sent){
        if(Netlify.env.get("ADMIN_RESET_ALLOW_DEV_CODE")==="true") return json({resetCode:c,warning:"Email provider is not configured; development reset code returned."});
        return json({error:"Reset email could not be sent. Configure RESEND_API_KEY and ADMIN_RESET_FROM in Netlify."},503);
      }
      return json({message:"A password reset code has been sent to the administrator email."});
    }
    if(b.action==="reset-password"){
      if(!b.email||b.email!==ADMIN_EMAIL()||!b.code||!b.newPassword||String(b.newPassword).length<8)return json({error:"Email, reset code and a new password of at least 8 characters are required."},400);
      const r=await read("adminReset",null);
      if(!r||r.expiresAt<Date.now()||r.codeHash!==hash(String(b.code)))return json({error:"Invalid or expired reset code."},400);
      await write("adminSettings",{password:String(b.newPassword),updatedAt:now()});
      await write("adminReset",null);
      const pass=String(b.newPassword);
      return json({message:"Admin password updated successfully.",token:token(ADMIN_EMAIL(),pass)});
    }
    return json({error:"Unknown admin action"},400);
  }
  if(req.method==="GET"){const pass=await currentPassword();if(req.headers.get("Authorization")!==`Bearer ${token(ADMIN_EMAIL(),pass)}`)return json({error:"Unauthorized"},401);const users=await read("users",[]),orders=await read("orders",[]),promotions=await read("promotions",[]);return json({stats:{users:users.length,sellers:users.filter(x=>x.role==="seller").length,orders:orders.length,revenue:orders.filter(x=>x.status==="paid").reduce((a,x)=>a+x.amount,0),commissions:orders.filter(x=>x.status==="paid").reduce((a,x)=>a+x.commission,0),promotionFees:orders.filter(x=>x.status==="paid").reduce((a,x)=>a+x.promotionFee,0)},users:users.map(x=>({phone:x.phone,role:x.role,businessName:x.businessName,status:x.status})),orders,promotions})}
  return json({error:"Method not allowed"},405)
}
export const config={path:"/api/admin"};
