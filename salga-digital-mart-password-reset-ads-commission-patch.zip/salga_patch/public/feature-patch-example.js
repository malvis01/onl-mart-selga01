/* Frontend wiring examples. Adapt selectors to the existing Salga Digital Mart UI. */

export async function requestPasswordReset(email) {
  const r = await fetch('/api/auth/request-password-reset', {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email })
  });
  return r.json();
}

export async function finishPasswordReset(email, code, newPassword) {
  const r = await fetch('/api/auth/verify-password-reset', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, code, newPassword })
  });
  return r.json();
}

export async function createAdCampaign({ businessId, title, amount, startsAt, endsAt }) {
  const r = await fetch('/api/ads/create-campaign', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ businessId, title, amount, startsAt, endsAt })
  });
  return r.json();
}
