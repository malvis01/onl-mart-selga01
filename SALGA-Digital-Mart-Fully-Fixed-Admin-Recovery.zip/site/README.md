# SALGA Digital Mart – fixed deployment package

This package includes the marketplace frontend and Netlify Functions.

## Required Netlify environment variables

Set these in Netlify before production use:

- `ADMIN_EMAIL` – administrator email address.
- `ADMIN_PASSWORD` – initial administrator password. After the first successful password reset, the new password is stored securely in Netlify Blobs and takes precedence.
- `RESEND_API_KEY` – API key for sending admin password-recovery email.
- `ADMIN_RESET_FROM` – verified sender, e.g. `SALGA Digital Mart <admin@your-domain.com>`.
- `PAYSTACK_SECRET_KEY` – Paystack secret key for real payments and seller subaccounts.
- `OPENAI_API_KEY` – optional, for AI customer care.

For a temporary development-only reset test, `ADMIN_RESET_ALLOW_DEV_CODE=true` can be set. Do not use this in production because it allows the reset code to be returned to the browser when email sending is unavailable.

## Admin password recovery

1. Open **Admin** on the website.
2. Select **Forgot admin password?**.
3. Enter the administrator email.
4. The site sends a six-digit reset code to that email.
5. Enter the code and set a new password (minimum 8 characters).
6. The new password is saved in Netlify Blobs and immediately becomes the active admin password.

## Deployment

This is a Netlify project. Keep `netlify.toml` at the project root and deploy the project through a Netlify build or Git-connected deployment so the Netlify Functions are installed and published.
