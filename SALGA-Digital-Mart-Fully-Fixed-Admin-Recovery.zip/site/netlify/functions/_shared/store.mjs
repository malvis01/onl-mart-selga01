import {getStore} from "@netlify/blobs";
export const db=()=>getStore({name:"salga-market",consistency:"strong"});
export async function read(key,fallback){const v=await db().get(key,{type:"json"});return v??fallback}
export async function write(key,v){await db().setJSON(key,v);return v}
export function id(prefix="id"){return prefix+"_"+crypto.randomUUID().replaceAll("-","")}
export function now(){return new Date().toISOString()}
export function hash(s){let h=0;for(let i=0;i<s.length;i++)h=(Math.imul(31,h)+s.charCodeAt(i))|0;return String(h>>>0)}
export function json(x,status=200){return new Response(JSON.stringify(x),{status,headers:{"content-type":"application/json"}})}
export async function body(req){return await req.json().catch(()=>({}))}
